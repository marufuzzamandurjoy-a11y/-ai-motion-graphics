// Original, deterministic, copyright-free audio — synthesized from scratch.
// Writes 16-bit mono WAVs to public/sfx and public/music, then prints a validation table.
import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";

const SR = 44100;
const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
fs.mkdirSync(path.join(root, "public/sfx"), {recursive: true});
fs.mkdirSync(path.join(root, "public/music"), {recursive: true});

let seed = 1234567;
const rand = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 4294967296 * 2 - 1;
};
const buf = (sec) => new Float32Array(Math.round(sec * SR));
const TAU = Math.PI * 2;

function finish(b, peak = 0.8, fade = 0.004) {
  let m = 0;
  for (const v of b) m = Math.max(m, Math.abs(v));
  const g = m > 0 ? peak / m : 1;
  const fn = Math.round(fade * SR);
  for (let i = 0; i < b.length; i++) {
    let v = b[i] * g;
    if (i < fn) v *= i / fn;
    if (i > b.length - fn) v *= (b.length - i) / fn;
    b[i] = v;
  }
  return b;
}

// band-pass (state variable filter) noise with time-varying centre frequency
function bandNoise(b, f0, f1, q, env) {
  let low = 0, band = 0;
  for (let i = 0; i < b.length; i++) {
    const t = i / b.length;
    const fc = f0 * Math.pow(f1 / f0, t);
    const f = 2 * Math.sin(Math.PI * fc / SR);
    const x = rand();
    low += f * band;
    const high = x - low - band / q;
    band += f * high;
    b[i] = band * env(t);
  }
}

const sounds = {
  pop() {
    const b = buf(0.18);
    let ph = 0;
    for (let i = 0; i < b.length; i++) {
      const t = i / SR;
      const f = 260 + 300 * Math.exp(-t * 38);
      ph += TAU * f / SR;
      b[i] = Math.sin(ph) * Math.exp(-t * 26);
    }
    return finish(b);
  },
  click() {
    const b = buf(0.09);
    let lp = 0;
    for (let i = 0; i < b.length; i++) {
      const t = i / SR;
      lp += 0.35 * (rand() - lp);
      b[i] = (lp * 1.2 + Math.sin(TAU * 1700 * t) * 0.5) * Math.exp(-t * 90);
    }
    return finish(b);
  },
  tick() {
    const b = buf(0.06);
    for (let i = 0; i < b.length; i++) {
      const t = i / SR;
      b[i] = Math.sin(TAU * 2400 * t) * Math.exp(-t * 110);
    }
    return finish(b);
  },
  whoosh() {
    const b = buf(0.75);
    bandNoise(b, 250, 3200, 1.4, (t) => Math.sin(Math.PI * Math.pow(t, 0.7)) ** 2);
    return finish(b, 0.8, 0.02);
  },
  chime() {
    const b = buf(0.55);
    const partials = [[880, 1, 7], [1320, 0.5, 9], [1760, 0.28, 12], [2640, 0.12, 16]];
    let lp = 0;
    for (let i = 0; i < b.length; i++) {
      const t = i / SR;
      let v = 0;
      for (const [f, a, d] of partials) v += Math.sin(TAU * f * t) * a * Math.exp(-t * d);
      lp += 0.5 * (v - lp);
      b[i] = lp * Math.min(1, t / 0.003);
    }
    return finish(b);
  },
  impact() {
    const b = buf(0.5);
    let ph = 0, lp = 0;
    for (let i = 0; i < b.length; i++) {
      const t = i / SR;
      ph += TAU * (46 + 40 * Math.exp(-t * 14)) / SR;
      lp += 0.06 * (rand() - lp);
      b[i] = Math.sin(ph) * Math.exp(-t * 9) + lp * 2.2 * Math.exp(-t * 30);
    }
    return finish(b, 0.8, 0.006);
  },
};

function writeWav(file, data) {
  const out = Buffer.alloc(44 + data.length * 2);
  out.write("RIFF", 0); out.writeUInt32LE(36 + data.length * 2, 4); out.write("WAVE", 8);
  out.write("fmt ", 12); out.writeUInt32LE(16, 16); out.writeUInt16LE(1, 20); out.writeUInt16LE(1, 22);
  out.writeUInt32LE(SR, 24); out.writeUInt32LE(SR * 2, 28); out.writeUInt16LE(2, 32); out.writeUInt16LE(16, 34);
  out.write("data", 36); out.writeUInt32LE(data.length * 2, 40);
  for (let i = 0; i < data.length; i++) out.writeInt16LE(Math.round(Math.max(-1, Math.min(1, data[i])) * 32767), 44 + i * 2);
  fs.writeFileSync(file, out);
}

// ambient pad: detuned sines on an A-minor chord, slow swells (no melody, no beat)
function pad(sec) {
  const b = buf(sec);
  const notes = [110, 164.81, 220, 261.63, 329.63];
  for (let i = 0; i < b.length; i++) {
    const t = i / SR;
    let v = 0;
    notes.forEach((f, k) => {
      const swell = 0.6 + 0.4 * Math.sin(TAU * (0.05 + k * 0.013) * t + k);
      v += (Math.sin(TAU * f * t) + Math.sin(TAU * f * 1.003 * t)) * 0.5 * swell / (1 + k * 0.35);
    });
    b[i] = v;
  }
  return finish(b, 0.7, 1.5);
}

const report = [];
const stat = (name, d) => {
  let pk = 0, ss = 0, clip = 0;
  for (const v of d) { pk = Math.max(pk, Math.abs(v)); ss += v * v; if (Math.abs(v) >= 0.999) clip++; }
  const rms = Math.sqrt(ss / d.length);
  report.push({name, sec: +(d.length / SR).toFixed(2), peakdB: +(20 * Math.log10(pk)).toFixed(1), rmsdB: +(20 * Math.log10(rms)).toFixed(1), clipped: clip});
};

for (const [n, fn] of Object.entries(sounds)) {
  const d = fn();
  writeWav(path.join(root, "public/sfx", `${n}.wav`), d);
  stat(`sfx/${n}`, d);
}
const p = pad(41.5);
writeWav(path.join(root, "public/music/pad.wav"), p);
stat("music/pad", p);
console.table(report);
