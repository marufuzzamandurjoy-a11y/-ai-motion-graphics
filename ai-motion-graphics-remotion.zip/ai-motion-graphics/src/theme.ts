// Single source of truth for every visual constant.
import {Easing} from "remotion";
import {loadFont} from "@remotion/google-fonts/HindSiliguri";

// Ligature-friendly Bengali + Latin face. Loaded once; Remotion waits for it.
const {fontFamily} = loadFont("normal", {
  weights: ["500", "600", "700"],
  subsets: ["bengali", "latin"],
});

export const theme = {
  colors: {
    bg: "#04050D",
    bgAlt: "#0B1236",
    primary: "#2F7BFF", // electric blue — the hero
    accent: "#8B5CF6", // purple
    text: "#F5F7FF",
    textDim: "#98A3C9",
    glass: "rgba(255,255,255,0.06)",
    glassStrong: "rgba(255,255,255,0.11)",
    line: "rgba(255,255,255,0.14)",
    black: "#000000",
  },
  fonts: {
    display: `${fontFamily}, "Noto Sans Bengali", "Hind Siliguri", sans-serif`,
  },
  weights: {regular: 500, semi: 600, bold: 700},
  radius: {sm: 20, md: 32, lg: 44, pill: 999},
  shadow: {
    card: "0 40px 80px -24px rgba(0,0,0,0.65)",
    glowPrimary: "0 0 60px rgba(47,123,255,0.45), 0 0 140px rgba(47,123,255,0.25)",
    glowAccent: "0 0 60px rgba(139,92,246,0.45), 0 0 140px rgba(139,92,246,0.25)",
  },
  size: {hero: 190, h1: 130, h2: 96, h3: 72, body: 52, small: 40},
  space: 8,
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
  },
} as const;

export type SpringCfg = {damping: number; stiffness: number; mass: number};
