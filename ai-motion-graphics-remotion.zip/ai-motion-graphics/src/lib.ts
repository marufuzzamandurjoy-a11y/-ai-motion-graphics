import {interpolate, spring} from "remotion";
import {theme} from "./theme";
import type {SpringCfg} from "./theme";

export const clamp01 = (n: number) => Math.min(1, Math.max(0, n));
export const mix = (a: number, b: number, t: number) => a + (b - a) * t;
export const mod = (n: number, m: number) => ((n % m) + m) % m;

/** Eased 0→1 progress between two frames (always clamped, never linear). */
export const p = (
  frame: number,
  from: number,
  to: number,
  easing: (t: number) => number = theme.ease.out,
) => {
  if (to <= from) return frame >= to ? 1 : 0;
  return interpolate(frame, [from, to], [0, 1], {
    easing,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
};

/** Spring that starts at `delay` (0 before it). */
export const sp = (
  frame: number,
  delay: number,
  fps: number,
  config: SpringCfg = theme.spring.smooth,
) => spring({frame: frame - delay, fps, config});

/** Deterministic PRNG (mulberry32) so renders are reproducible. */
export const rng = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};
