// Format + audio switches. Vertical 9:16, 30 FPS.
export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

// Voiceover length (from the supplied MP3) + a short calm tail.
export const VOICEOVER_SECONDS = 40.281;
export const TAIL_SECONDS = 0.5;
export const TOTAL_FRAMES = Math.ceil((VOICEOVER_SECONDS + TAIL_SECONDS) * FPS);

// Audio on/off flags (also editable live in Remotion Studio's "Props" panel).
export type MainProps = {
  voiceover: boolean;
  sfx: boolean;
  music: boolean;
};
export const AUDIO_DEFAULTS: MainProps = {voiceover: true, sfx: true, music: true};
