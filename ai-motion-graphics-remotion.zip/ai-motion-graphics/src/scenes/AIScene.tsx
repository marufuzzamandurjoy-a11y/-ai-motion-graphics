import React from "react";
import {useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {mod, p, sp} from "../lib";
import {makeAt} from "../timing";
import {Words} from "../components/Text";

const CX = 540;
const CY = 700;
const CARD = 270;
const CARDS = [
  {x: 200, y: 430, at: 14.0},
  {x: 880, y: 430, at: 14.25},
  {x: 200, y: 970, at: 14.5},
  {x: 880, y: 970, at: 14.75},
];

const MiniContent: React.FC<{kind: number; frame: number}> = ({kind, frame}) => {
  const c = theme.colors;
  if (kind === 0) {
    return (
      <div style={{display: "flex", alignItems: "flex-end", gap: 14, height: 150}}>
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <div
            key={i}
            style={{
              width: 24,
              height: 40 + 110 * (0.5 + 0.5 * Math.sin(frame / 6 + i * 0.9)),
              borderRadius: 12,
              background: i % 2 === 0 ? c.primary : c.accent,
            }}
          />
        ))}
      </div>
    );
  }
  if (kind === 1) {
    return (
      <div style={{position: "relative", width: 150, height: 150}}>
        <div
          style={{
            position: "absolute",
            inset: 10,
            borderRadius: 30,
            border: `5px solid ${c.primary}`,
            transform: `rotate(${frame * 1.8}deg)`,
            boxShadow: `0 0 30px ${c.primary}66`,
          }}
        />
        <div
          style={{
            position: "absolute",
            left: 55,
            top: 55,
            width: 40,
            height: 40,
            borderRadius: "50%",
            background: c.accent,
            transform: `scale(${1 + 0.25 * Math.sin(frame / 7)})`,
          }}
        />
      </div>
    );
  }
  if (kind === 2) {
    return (
      <div style={{position: "relative", width: 190, height: 190}}>
        {[0, 1, 2].map((j) => {
          const t = mod(frame / 42 + j / 3, 1);
          const s = 30 + t * 160;
          return (
            <div
              key={j}
              style={{
                position: "absolute",
                left: 95 - s / 2,
                top: 95 - s / 2,
                width: s,
                height: s,
                borderRadius: "50%",
                border: `5px solid ${c.accent}`,
                opacity: 1 - t,
              }}
            />
          );
        })}
      </div>
    );
  }
  const pts = Array.from({length: 26}).map((_, i) => {
    const x = (i / 25) * 210;
    const y = 60 + 36 * Math.sin(i * 0.55 + frame / 8);
    return `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
  });
  return (
    <svg width={210} height={120} viewBox="0 0 210 120">
      <path d={pts.join(" ")} fill="none" stroke={c.primary} strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};

export const AIScene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = makeAt("ai");

  const ignite = Math.max(0, sp(frame, at(12.75), fps, theme.spring.bouncy));
  const pulse = p(frame, at(12.75), at(12.75) + 26, theme.ease.out);
  const aiK = Math.max(0, sp(frame, at(13.05), fps, theme.spring.bouncy));
  const breathe = 1 + Math.sin(frame / 18) * 0.03;

  return (
    <div style={{position: "absolute", inset: 0}}>
      {/* spokes */}
      <svg width={1080} height={1920} style={{position: "absolute", left: 0, top: 0}}>
        {CARDS.map((cd, i) => {
          const len = Math.hypot(cd.x - CX, cd.y - CY);
          const k = p(frame, at(cd.at) - 6, at(cd.at) + 12, theme.ease.out);
          return (
            <line
              key={i}
              x1={CX}
              y1={CY}
              x2={cd.x}
              y2={cd.y}
              stroke={theme.colors.accent}
              strokeOpacity={0.55}
              strokeWidth={3}
              strokeDasharray={`${len}`}
              strokeDashoffset={len * (1 - k)}
              strokeLinecap="round"
            />
          );
        })}
      </svg>

      {/* ignition ring */}
      <div
        style={{
          position: "absolute",
          left: CX - 350,
          top: CY - 350,
          width: 700,
          height: 700,
          borderRadius: "50%",
          border: `6px solid ${theme.colors.primary}`,
          opacity: (1 - pulse) * 0.8,
          transform: `scale(${0.2 + pulse * 1.6})`,
        }}
      />

      {/* orb */}
      <div style={{position: "absolute", left: CX - 280, top: CY - 280, width: 560, height: 560, transform: `scale(${ignite * breathe})`}}>
        <svg width={560} height={560} viewBox="-280 -280 560 560">
          <g transform={`rotate(${frame * 0.6})`}>
            <circle r={170} fill="none" stroke={theme.colors.primary} strokeOpacity={0.7} strokeWidth={3} strokeDasharray="22 16" />
          </g>
          <g transform={`rotate(${-frame * 0.4})`}>
            <circle r={215} fill="none" stroke={theme.colors.accent} strokeOpacity={0.6} strokeWidth={2} />
            {[0, 1, 2].map((i) => {
              const a = (i / 3) * Math.PI * 2;
              return <circle key={i} cx={Math.cos(a) * 215} cy={Math.sin(a) * 215} r={9} fill={theme.colors.text} />;
            })}
          </g>
          <g transform={`rotate(${frame * 0.25})`}>
            <circle r={258} fill="none" stroke={theme.colors.text} strokeOpacity={0.35} strokeWidth={3} strokeDasharray="2 18" strokeLinecap="round" />
          </g>
        </svg>
        <div
          style={{
            position: "absolute",
            left: 130,
            top: 130,
            width: 300,
            height: 300,
            borderRadius: "50%",
            background: `radial-gradient(circle at 35% 30%, #FFFFFF 0%, ${theme.colors.primary} 34%, ${theme.colors.accent} 72%, transparent 74%)`,
            boxShadow: `${theme.shadow.glowPrimary}, ${theme.shadow.glowAccent}`,
          }}
        />
      </div>

      {/* "AI" on the core */}
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: CY - 135,
          display: "flex",
          justifyContent: "center",
          opacity: Math.min(1, aiK),
          transform: `scale(${0.6 + 0.4 * aiK})`,
          fontFamily: theme.fonts.display,
          fontSize: 190,
          fontWeight: theme.weights.bold,
          lineHeight: 1.42,
          letterSpacing: 0,
          color: theme.colors.text,
          textShadow: "0 6px 30px rgba(4,5,13,0.55)",
        }}
      >
        AI
      </div>

      {/* generated outputs (hub & spoke) */}
      {CARDS.map((cd, i) => {
        const k = Math.max(0, sp(frame, at(cd.at), fps, theme.spring.bouncy));
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: cd.x - CARD / 2,
              top: cd.y - CARD / 2,
              width: CARD,
              height: CARD,
              borderRadius: theme.radius.md,
              background: "rgba(14,20,52,0.82)",
              border: `2px solid ${theme.colors.line}`,
              boxShadow: theme.shadow.card,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              opacity: Math.min(1, k),
              transform: `scale(${0.6 + 0.4 * k}) translateY(${(1 - Math.min(1, k)) * 40}px)`,
            }}
          >
            <MiniContent kind={i} frame={frame} />
          </div>
        );
      })}

      {/* headline */}
      <div style={{position: "absolute", top: 1270, left: 0, right: 0, display: "flex", flexDirection: "column", alignItems: "center"}}>
        <Words text="অসাধারণ" start={at(16.45)} size={84} color={theme.colors.textDim} weight={theme.weights.semi} />
        <Words text="Motion Graphics ভিডিও!" start={at(17.3)} per={7} size={92} hi={[0, 1]} style={{marginTop: 6}} />
      </div>
    </div>
  );
};
