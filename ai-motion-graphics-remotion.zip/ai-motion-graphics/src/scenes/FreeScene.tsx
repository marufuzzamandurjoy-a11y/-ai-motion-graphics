import React from "react";
import {useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {p, sp} from "../lib";
import {makeAt} from "../timing";
import {Words} from "../components/Text";
import {CrossIcon, SparkIcon} from "../components/Icons";

const CrossCard: React.FC<{label: string; top: number; show: number; strikeAt: number}> = ({label, top, show, strikeAt}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const k = sp(frame, show, fps, theme.spring.smooth);
  const o = Math.min(1, Math.max(0, k));
  const s = p(frame, strikeAt, strikeAt + 9, theme.ease.out);
  const badge = Math.max(0, sp(frame, strikeAt + 2, fps, theme.spring.bouncy));
  return (
    <div
      style={{
        position: "absolute",
        left: 110,
        top,
        width: 860,
        height: 200,
        borderRadius: theme.radius.md,
        background: "rgba(14,20,52,0.82)",
        border: `2px solid ${theme.colors.line}`,
        boxShadow: theme.shadow.card,
        display: "flex",
        alignItems: "center",
        padding: "0 44px",
        opacity: o * (1 - 0.4 * s),
        transform: `translateY(${(1 - k) * 60}px) scale(${0.95 + 0.05 * k})`,
      }}
    >
      <div
        style={{
          position: "relative",
          fontFamily: theme.fonts.display,
          fontSize: 66,
          fontWeight: theme.weights.bold,
          lineHeight: 1.42,
          letterSpacing: 0,
          color: theme.colors.text,
        }}
      >
        <div style={{position: "relative", display: "inline-block"}}>
          {label}
          <div
            style={{
              position: "absolute",
              left: -14,
              top: "56%",
              height: 10,
              borderRadius: 5,
              width: `calc(${s * 100}% + ${s * 28}px)`,
              background: `linear-gradient(90deg, ${theme.colors.accent}, #B79BFF)`,
              boxShadow: theme.shadow.glowAccent,
            }}
          />
        </div>
      </div>
      <div style={{flex: 1}} />
      <div
        style={{
          width: 88,
          height: 88,
          borderRadius: "50%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: `linear-gradient(135deg, ${theme.colors.primary}, ${theme.colors.accent})`,
          opacity: Math.min(1, badge),
          transform: `scale(${badge})`,
        }}
      >
        <CrossIcon size={46} />
      </div>
    </div>
  );
};

export const FreeScene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = makeAt("free");

  const sparkIn = Math.max(0, sp(frame, at(29.85), fps, theme.spring.bouncy));
  const sparkOut = p(frame, at(31.45), at(31.85), theme.ease.in);
  const spin = frame * 1.2;
  const kickerOut = p(frame, at(31.4), at(31.75), theme.ease.in);

  return (
    <div style={{position: "absolute", inset: 0}}>
      <div style={{position: "absolute", top: 420, left: 0, right: 0, display: "flex", justifyContent: "center"}}>
        <Words text="সবচেয়ে মজার বিষয়" start={at(29.6)} per={7} size={72} color={theme.colors.textDim} weight={theme.weights.semi} out={kickerOut} />
      </div>

      {/* spark */}
      <div
        style={{
          position: "absolute",
          left: 540 - 130,
          top: 890 - 130,
          width: 260,
          height: 260,
          opacity: Math.min(1, sparkIn) * (1 - sparkOut),
          transform: `scale(${sparkIn * (1 - 0.5 * sparkOut)}) rotate(${spin}deg)`,
          filter: `drop-shadow(0 0 40px rgba(47,123,255,0.7))`,
        }}
      >
        <SparkIcon size={260} color={theme.colors.primary} />
      </div>

      <div style={{position: "absolute", top: 590, left: 0, right: 0, display: "flex", justifyContent: "center"}}>
        <Words text="শুরু করতে" start={at(31.5)} per={6} size={64} color={theme.colors.textDim} weight={theme.weights.semi} />
      </div>
      <div style={{position: "absolute", top: 680, left: 0, right: 0, display: "flex", justifyContent: "center"}}>
        <Words text="দরকার নেই" start={at(32.1)} per={8} size={176} hi={[0, 1]} />
      </div>

      <CrossCard label="দামি সফটওয়্যার" top={1050} show={at(32.75)} strikeAt={at(33.5)} />
      <CrossCard label="বছরের পর বছর অভিজ্ঞতা" top={1310} show={at(33.6)} strikeAt={at(34.7)} />
    </div>
  );
};
