import React from "react";
import {useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {mod, p, sp} from "../lib";
import {makeAt, sceneDuration} from "../timing";
import {Words, gradientText} from "../components/Text";
import {Chip} from "../components/Chip";
import {Entrance} from "../components/Entrance";
import {ArrowIcon} from "../components/Icons";

const RAYS = 12;

export const CtaScene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = makeAt("cta");
  const dur = sceneDuration("cta");

  // slow cinematic pull-back
  const cam = 1.08 - 0.08 * p(frame, 0, dur, theme.ease.inOut);

  // phase 1 — calm question
  const q = p(frame, at(36.7), at(37.0), theme.ease.in);
  // phase 3 — chips make way for the wordmark
  const chipsOut = p(frame, at(39.0), at(39.2), theme.ease.in);

  const sparkIn = Math.max(0, sp(frame, at(37.0), fps, theme.spring.smooth));
  const sparkDim = 1 - 0.35 * p(frame, at(39.1), at(39.6));
  const wm = Math.max(0, sp(frame, at(39.15), fps, theme.spring.bouncy));
  const cta = Math.max(0, sp(frame, at(38.5), fps, theme.spring.bouncy));
  const sweep = mod(frame / 70, 1);

  return (
    <div style={{position: "absolute", inset: 0, transform: `scale(${cam})`}}>
      {/* soft pulse rings behind the question */}
      <div style={{opacity: 1 - q}}>
        {[0, 1, 2].map((j) => {
          const t = mod(frame / 90 + j / 3, 1);
          const s = 200 + t * 700;
          return (
            <div
              key={j}
              style={{
                position: "absolute",
                left: 540 - s / 2,
                top: 900 - s / 2,
                width: s,
                height: s,
                borderRadius: "50%",
                border: `3px solid ${theme.colors.primary}`,
                opacity: (1 - t) * 0.5,
              }}
            />
          );
        })}
        <div style={{position: "absolute", top: 690, left: 0, right: 0, display: "flex", justifyContent: "center"}}>
          <Words text="তাহলে আর" start={at(35.45)} per={5} size={72} color={theme.colors.textDim} weight={theme.weights.semi} />
        </div>
        <div style={{position: "absolute", top: 800, left: 0, right: 0, display: "flex", justifyContent: "center"}}>
          <Words text="অপেক্ষা কেন?" start={at(35.62)} per={12} size={170} hi={[1]} />
        </div>
      </div>

      {/* idea spark */}
      <div
        style={{
          position: "absolute",
          left: 540 - 150,
          top: 520 - 150,
          width: 300,
          height: 300,
          opacity: Math.min(1, sparkIn) * sparkDim,
          transform: `scale(${0.4 + 0.6 * sparkIn}) rotate(${-120 * (1 - Math.min(1, sparkIn)) + frame * 0.4}deg)`,
          filter: `drop-shadow(0 0 ${Math.round(70 * sparkDim)}px rgba(47,123,255,0.7))`,
        }}
      >
        {Array.from({length: RAYS}).map((_, i) => {
          const k = Math.max(0, sp(frame, at(37.0) + i * 1.2, fps, theme.spring.snappy));
          return (
            <div
              key={i}
              style={{
                position: "absolute",
                left: "50%",
                top: "50%",
                width: 26,
                height: 138 * Math.min(1.1, k),
                background: i % 2 === 0 ? theme.colors.primary : theme.colors.accent,
                borderRadius: 300,
                transformOrigin: "50% 0%",
                transform: `translateX(-50%) rotate(${(360 / RAYS) * i}deg) translateY(20px)`,
              }}
            />
          );
        })}
      </div>

      {/* আইডিয়া → বাস্তব */}
      <div
        style={{
          position: "absolute",
          top: 780,
          left: 0,
          right: 0,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: 28,
          opacity: 1 - chipsOut,
        }}
      >
        <Chip label="আইডিয়া" delay={at(37.15)} size={62} />
        <Entrance delay={at(37.6)} y={0} s0={0.6} cfg={theme.spring.snappy}>
          <ArrowIcon size={64} color={theme.colors.textDim} />
        </Entrance>
        <Chip label="বাস্তব" delay={at(37.95)} size={62} active />
      </div>

      {/* wordmark */}
      <div style={{position: "absolute", top: 740, left: 0, right: 0, display: "flex", flexDirection: "column", alignItems: "center", opacity: Math.min(1, wm), transform: `scale(${0.8 + 0.2 * wm})`}}>
        <div
          style={{
            fontFamily: theme.fonts.display,
            fontSize: 240,
            fontWeight: theme.weights.bold,
            lineHeight: 1.3,
            letterSpacing: 0,
            filter: "drop-shadow(0 0 40px rgba(47,123,255,0.55))",
            ...gradientText(),
          }}
        >
          AI
        </div>
        <div
          style={{
            fontFamily: theme.fonts.display,
            fontSize: 124,
            fontWeight: theme.weights.bold,
            lineHeight: 1.3,
            letterSpacing: 0,
            color: theme.colors.text,
          }}
        >
          Motion Graphics
        </div>
      </div>

      {/* CTA */}
      <div style={{position: "absolute", top: 1360, left: 0, right: 0, display: "flex", justifyContent: "center", opacity: Math.min(1, cta), transform: `translateY(${(1 - cta) * 50}px) scale(${0.85 + 0.15 * Math.min(1.05, cta)})`}}>
        <div
          style={{
            position: "relative",
            overflow: "hidden",
            padding: "20px 64px",
            borderRadius: theme.radius.pill,
            background: `linear-gradient(100deg, ${theme.colors.primary}, ${theme.colors.accent})`,
            boxShadow: theme.shadow.glowPrimary,
            fontFamily: theme.fonts.display,
            fontSize: 62,
            fontWeight: theme.weights.bold,
            lineHeight: 1.4,
            letterSpacing: 0,
            color: theme.colors.text,
          }}
        >
          আজ থেকেই শুরু করো
          <div
            style={{
              position: "absolute",
              top: 0,
              bottom: 0,
              left: `${-40 + sweep * 180}%`,
              width: "30%",
              background: "linear-gradient(100deg, transparent, rgba(255,255,255,0.35), transparent)",
              transform: "skewX(-20deg)",
            }}
          />
        </div>
      </div>
    </div>
  );
};
