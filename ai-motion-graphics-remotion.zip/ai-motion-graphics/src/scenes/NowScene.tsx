import React from "react";
import {useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {mix, p, sp} from "../lib";
import {makeAt} from "../timing";
import {Words} from "../components/Text";

const Center: React.FC<{top: number; children?: React.ReactNode; style?: React.CSSProperties}> = ({top, children, style}) => (
  <div style={{position: "absolute", top, left: 0, right: 0, display: "flex", justifyContent: "center", ...style}}>
    {children}
  </div>
);

export const NowScene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = makeAt("now");

  // collapsing-timeline flash at the cut
  const flash = p(frame, 6, 26, theme.ease.out);
  // "কিন্তু এখন?" exits right before the next idea
  const out1 = p(frame, at(8.45), at(8.8), theme.ease.in);
  const breathe = 1 + Math.sin(frame / 20) * 0.012;

  // skill meter
  const labelK = sp(frame, at(9.85), fps, theme.spring.smooth);
  const strike = p(frame, at(11.25), at(11.5), theme.ease.out);
  const labelDim = 1 - 0.62 * strike;
  const trackK = Math.min(1, Math.max(0, sp(frame, at(9.95), fps, theme.spring.smooth)));
  const cursorPulse = 0.6 + 0.4 * Math.sin(frame / 6);

  return (
    <div style={{position: "absolute", inset: 0}}>
      {/* spark of light left by the collapsed timeline */}
      <div
        style={{
          position: "absolute",
          left: 540 - 400,
          top: 900 - 400,
          width: 800,
          height: 800,
          borderRadius: "50%",
          background: `radial-gradient(circle, ${theme.colors.primary}88, transparent 62%)`,
          opacity: (1 - flash) * 0.9,
          transform: `scale(${mix(0.2, 1.6, flash)})`,
        }}
      />

      {/* কিন্তু এখন? */}
      <div style={{opacity: 1 - out1, transform: `scale(${breathe})`}}>
        <Center top={620}>
          <Words text="কিন্তু" start={at(6.45)} size={190} />
        </Center>
        <Center top={880}>
          <Words text="এখন?" start={at(7.25)} size={240} hi={[0]} />
        </Center>
      </div>

      {/* এখন তোমার কাছে … প্রফেশনাল স্কিল … না-ও থাকে */}
      <Center top={560}>
        <Words text="এখন তোমার কাছে" start={at(8.85)} per={5} size={64} color={theme.colors.textDim} weight={theme.weights.semi} />
      </Center>

      <Center top={700}>
        <div
          style={{
            position: "relative",
            display: "inline-block",
            opacity: Math.min(1, Math.max(0, labelK)) * labelDim,
            transform: `translateY(${(1 - labelK) * 40}px) scale(${0.94 + 0.06 * labelK})`,
            fontFamily: theme.fonts.display,
            fontSize: 104,
            fontWeight: theme.weights.bold,
            lineHeight: 1.42,
            letterSpacing: 0,
            color: theme.colors.text,
          }}
        >
          প্রফেশনাল স্কিল
          <div
            style={{
              position: "absolute",
              left: -20,
              top: "54%",
              height: 9,
              borderRadius: 5,
              width: `${strike * 100}%`,
              background: `linear-gradient(90deg, ${theme.colors.accent}, ${theme.colors.primary})`,
              boxShadow: theme.shadow.glowAccent,
            }}
          />
        </div>
      </Center>

      {/* empty skill track */}
      <Center top={910}>
        <div
          style={{
            position: "relative",
            width: 760,
            height: 28,
            borderRadius: 14,
            background: theme.colors.glassStrong,
            border: `2px solid ${theme.colors.line}`,
            opacity: trackK,
            transform: `scaleX(${0.7 + 0.3 * trackK})`,
          }}
        >
          <div
            style={{
              position: "absolute",
              left: 4,
              top: 4,
              width: 16,
              height: 16,
              borderRadius: "50%",
              background: theme.colors.textDim,
              opacity: cursorPulse,
            }}
          />
        </div>
      </Center>

      <Center top={1040}>
        <Words text="না-ও থাকে" start={at(11.35)} per={12} size={170} hi={[0, 1]} />
      </Center>
    </div>
  );
};

