import React from "react";
import {useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {p, sp} from "../lib";
import {makeAt} from "../timing";
import {Words} from "../components/Text";
import {Chip} from "../components/Chip";
import {Entrance} from "../components/Entrance";
import {ArrowIcon, PenIcon, SendIcon, SparkIcon} from "../components/Icons";

const BOX_TOP = 950;
const BOX_H = 260;
const LINES = [
  {w: 640, at: 22.0},
  {w: 720, at: 22.45},
  {w: 380, at: 22.9},
];

export const PromptScene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = makeAt("prompt");

  const boxK = sp(frame, at(20.95), fps, theme.spring.smooth);
  const sendIn = Math.max(0, sp(frame, at(22.8), fps, theme.spring.bouncy));
  const press = p(frame, at(23.5), at(23.58), theme.ease.out);
  const release = p(frame, at(23.58), at(23.8), theme.ease.out);
  const sendScale = (0.6 + 0.4 * Math.min(1, sendIn)) * (1 - 0.14 * press * (1 - release));
  const ripple = p(frame, at(23.5), at(23.5) + 20, theme.ease.out);
  const caretOn = Math.floor(frame / 8) % 2 === 0;
  const fired = frame >= at(23.5);

  return (
    <div style={{position: "absolute", inset: 0}}>
      <div style={{position: "absolute", top: 500, left: 0, right: 0, display: "flex", justifyContent: "center"}}>
        <Words text="শুধু" start={at(20.8)} size={80} color={theme.colors.textDim} weight={theme.weights.semi} />
      </div>
      <div style={{position: "absolute", top: 620, left: 0, right: 0, display: "flex", justifyContent: "center"}}>
        <Words text="তোমার আইডিয়া" start={at(21.55)} per={12} size={130} hi={[1]} />
      </div>

      {/* prompt box */}
      <div
        style={{
          position: "absolute",
          left: 90,
          top: BOX_TOP,
          width: 900,
          height: BOX_H,
          borderRadius: theme.radius.lg,
          background: "rgba(14,20,52,0.82)",
          border: `2px solid ${fired ? theme.colors.primary : theme.colors.line}`,
          boxShadow: fired ? theme.shadow.glowPrimary : theme.shadow.card,
          opacity: Math.min(1, Math.max(0, boxK)),
          transform: `translateY(${(1 - boxK) * 70}px) scale(${0.95 + 0.05 * boxK})`,
        }}
      >
        <div style={{position: "absolute", left: 36, top: 34}}>
          <SparkIcon size={44} color={theme.colors.accent} />
        </div>
        {/* abstract prompt text (no per-letter Bengali animation) */}
        {LINES.map((ln, i) => {
          const w = ln.w * p(frame, at(ln.at), at(ln.at) + 14, theme.ease.out);
          return (
            <div
              key={i}
              style={{
                position: "absolute",
                left: 104,
                top: 40 + i * 52,
                width: w,
                height: 20,
                borderRadius: 10,
                background: i === 0 ? "rgba(245,247,255,0.78)" : "rgba(245,247,255,0.5)",
              }}
            />
          );
        })}
        {frame >= at(22.0) && !fired ? (
          <div
            style={{
              position: "absolute",
              left: 104 + 380 + 14,
              top: 32 + 2 * 52,
              width: 5,
              height: 44,
              borderRadius: 3,
              background: theme.colors.primary,
              opacity: caretOn ? 1 : 0.1,
            }}
          />
        ) : null}
        {/* send button */}
        <div
          style={{
            position: "absolute",
            right: 30,
            bottom: 30,
            width: 104,
            height: 104,
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: 0,
              borderRadius: "50%",
              border: `4px solid ${theme.colors.primary}`,
              opacity: (1 - ripple) * (fired ? 0.9 : 0),
              transform: `scale(${1 + ripple * 1.2})`,
            }}
          />
          <div
            style={{
              position: "absolute",
              inset: 0,
              borderRadius: "50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              background: fired
                ? `linear-gradient(135deg, ${theme.colors.primary}, ${theme.colors.accent})`
                : theme.colors.glassStrong,
              border: `2px solid ${fired ? "transparent" : theme.colors.line}`,
              opacity: Math.min(1, sendIn),
              transform: `scale(${sendScale})`,
            }}
          >
            <SendIcon size={52} />
          </div>
        </div>
      </div>

      {/* write → AI */}
      <div
        style={{
          position: "absolute",
          top: 1340,
          left: 0,
          right: 0,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: 26,
        }}
      >
        <Chip label="লিখে দাও" delay={at(22.75)} size={50} icon={<PenIcon size={44} color={theme.colors.textDim} />} />
        <Entrance delay={at(23.1)} y={0} s0={0.6} cfg={theme.spring.snappy}>
          <ArrowIcon size={54} color={theme.colors.textDim} />
        </Entrance>
        <Chip label="AI-কে" delay={at(23.35)} size={50} active />
      </div>
    </div>
  );
};
