import React from "react";
import {useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {mod, p, sp} from "../lib";
import {makeAt} from "../timing";
import {Words} from "../components/Text";
import {Chip} from "../components/Chip";
import {SendIcon} from "../components/Icons";

const STAGE_W = 920;
const STAGE_H = 760;
const STAGE_TOP = 450;

const Cube: React.FC<{size: number; rx: number; ry: number}> = ({size, rx, ry}) => {
  const h = size / 2;
  const face = (t: string, a: string, b: string): React.CSSProperties => ({
    position: "absolute",
    left: 0,
    top: 0,
    width: size,
    height: size,
    transform: t,
    background: `linear-gradient(135deg, ${a}, ${b})`,
    border: "2px solid rgba(255,255,255,0.38)",
    borderRadius: 18,
    boxShadow: "inset 0 0 40px rgba(255,255,255,0.12)",
  });
  const A = "rgba(47,123,255,0.55)";
  const B = "rgba(139,92,246,0.5)";
  return (
    <div style={{perspective: 1000}}>
      <div style={{position: "relative", width: size, height: size, transformStyle: "preserve-3d", transform: `rotateX(${rx}deg) rotateY(${ry}deg)`}}>
        <div style={face(`translateZ(${h}px)`, A, B)} />
        <div style={face(`rotateY(180deg) translateZ(${h}px)`, B, A)} />
        <div style={face(`rotateY(90deg) translateZ(${h}px)`, A, B)} />
        <div style={face(`rotateY(-90deg) translateZ(${h}px)`, B, A)} />
        <div style={face(`rotateX(90deg) translateZ(${h}px)`, A, A)} />
        <div style={face(`rotateX(-90deg) translateZ(${h}px)`, B, B)} />
      </div>
    </div>
  );
};

const fill: React.CSSProperties = {position: "absolute", left: 0, top: 0, right: 0, bottom: 0, display: "flex", alignItems: "center", justifyContent: "center"};

export const MagicScene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = makeAt("magic");

  const pillK = sp(frame, at(24.3), fps, theme.spring.smooth);
  const stageK = Math.max(0, sp(frame, at(24.45), fps, theme.spring.smooth));

  // stage timeline
  const wordsOut = p(frame, at(26.05), at(26.35), theme.ease.in);
  const aIn = p(frame, at(26.15), at(26.45));
  const aOut = p(frame, at(27.55), at(27.8), theme.ease.in);
  const bIn = p(frame, at(27.6), at(27.9));
  const bOut = p(frame, at(28.45), at(28.7), theme.ease.in);
  const cIn = p(frame, at(28.5), at(28.8));

  const cubeSpin = Math.max(0, frame - at(26.1));
  const prog = Math.max(0, frame - at(27.6)) / 22;
  const bar = Math.max(0, sp(frame, at(28.5), fps, theme.spring.smooth));
  const streak = p(frame, at(28.55), at(29.2), theme.ease.inOut);

  const active = frame >= at(28.45) ? 2 : frame >= at(27.55) ? 1 : frame >= at(26.9) ? 0 : -1;

  return (
    <div style={{position: "absolute", inset: 0}}>
      {/* collapsed prompt pill */}
      <div
        style={{
          position: "absolute",
          left: 220,
          top: 300,
          width: 640,
          height: 96,
          borderRadius: theme.radius.pill,
          background: "rgba(14,20,52,0.82)",
          border: `2px solid ${theme.colors.line}`,
          display: "flex",
          alignItems: "center",
          gap: 18,
          padding: "0 22px 0 36px",
          opacity: Math.min(1, Math.max(0, pillK)),
          transform: `translateY(${(1 - pillK) * 60}px)`,
        }}
      >
        <div style={{height: 14, width: 190, borderRadius: 7, background: "rgba(245,247,255,0.7)"}} />
        <div style={{height: 14, width: 130, borderRadius: 7, background: "rgba(245,247,255,0.4)"}} />
        <div style={{flex: 1}} />
        <div style={{width: 60, height: 60, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: `linear-gradient(135deg, ${theme.colors.primary}, ${theme.colors.accent})`}}>
          <SendIcon size={32} />
        </div>
      </div>

      {/* stage */}
      <div
        style={{
          position: "absolute",
          left: (1080 - STAGE_W) / 2,
          top: STAGE_TOP,
          width: STAGE_W,
          height: STAGE_H,
          borderRadius: theme.radius.lg,
          background: "rgba(10,14,40,0.8)",
          border: `2px solid ${theme.colors.line}`,
          boxShadow: theme.shadow.card,
          overflow: "hidden",
          opacity: Math.min(1, stageK),
          transform: `scale(${0.92 + 0.08 * Math.min(1, stageK)})`,
        }}
      >
        {/* plain words that will transform */}
        <div style={{...fill, opacity: 1 - wordsOut, transform: `scale(${1 - wordsOut * 0.7})`, filter: `blur(${wordsOut * 14}px)`}}>
          <Words text="সাধারণ কিছু শব্দ" start={at(24.7)} per={6} size={96} maxWidth={760} />
        </div>

        {/* A — animation: 3D cube */}
        <div style={{...fill, opacity: aIn * (1 - aOut), transform: `scale(${0.6 + 0.4 * aIn})`}}>
          <div style={{position: "absolute", width: 420, height: 420, borderRadius: "50%", border: `4px solid ${theme.colors.accent}`, opacity: 0.55, transform: `rotate(${cubeSpin * 2}deg) scaleY(0.35)`}} />
          <Cube size={230} rx={-24 + Math.sin(cubeSpin / 30) * 10} ry={cubeSpin * 3.2} />
        </div>

        {/* B — smooth transition: card carousel */}
        <div style={{...fill, opacity: bIn * (1 - bOut)}}>
          {[0, 1, 2, 3, 4].map((i) => {
            const whole = Math.floor(prog);
            const e = theme.ease.inOut(prog - whole);
            const pr = whole + e;
            const o = mod(i - pr + 2.5, 5) - 2.5;
            const ao = Math.abs(o);
            return (
              <div
                key={i}
                style={{
                  position: "absolute",
                  width: 280,
                  height: 380,
                  borderRadius: theme.radius.md,
                  background: i % 2 === 0
                    ? `linear-gradient(160deg, ${theme.colors.primary}, ${theme.colors.accent})`
                    : `linear-gradient(160deg, ${theme.colors.accent}, ${theme.colors.primary})`,
                  border: "2px solid rgba(255,255,255,0.3)",
                  opacity: 1 - 0.3 * Math.min(ao, 2),
                  transform: `translateX(${o * 330}px) scale(${1 - 0.18 * Math.min(ao, 2)})`,
                  zIndex: 10 - Math.round(ao),
                }}
              />
            );
          })}
        </div>

        {/* C — cinematic: light + letterbox */}
        <div style={{...fill, opacity: cIn}}>
          <div style={{position: "absolute", width: 360, height: 360, borderRadius: "50%", background: `radial-gradient(circle at 38% 34%, #FFFFFF 0%, ${theme.colors.primary} 38%, ${theme.colors.accent} 72%, transparent 74%)`, boxShadow: `${theme.shadow.glowPrimary}`, transform: `scale(${1 + Math.sin(frame / 14) * 0.03})`}} />
          <div style={{position: "absolute", left: -200 + streak * (STAGE_W + 400), top: STAGE_H / 2 - 3, width: 400, height: 6, borderRadius: 3, background: "linear-gradient(90deg, transparent, #FFFFFF, transparent)", boxShadow: "0 0 30px #FFFFFF"}} />
          <div style={{position: "absolute", left: 0, right: 0, top: 0, height: 120 * Math.min(1, bar), background: theme.colors.black}} />
          <div style={{position: "absolute", left: 0, right: 0, bottom: 0, height: 120 * Math.min(1, bar), background: theme.colors.black}} />
        </div>
      </div>

      {/* keyword list — current one is the hero */}
      <div style={{position: "absolute", left: 120, top: 1290, display: "flex", flexDirection: "column", gap: 18, alignItems: "flex-start"}}>
        <Chip label="Animation" delay={at(26.9)} size={46} active={active === 0} />
        <Chip label="Smooth Transition" delay={at(27.5)} size={46} active={active === 1} />
        <Chip label="Cinematic Visuals" delay={at(28.4)} size={46} active={active === 2} />
      </div>
    </div>
  );
};
