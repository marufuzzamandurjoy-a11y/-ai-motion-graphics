import React from "react";
import {useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {p, rng, sp} from "../lib";
import {makeAt, sceneDuration} from "../timing";
import {Words} from "../components/Text";
import {Chip} from "../components/Chip";
import {Entrance} from "../components/Entrance";

const ROW_NAMES = ["Position", "Scale", "Rotation", "Opacity", "Mask", "Effects", "Camera", "Light", "Null"];
const ROW_H = 64;
const PANEL_W = 960;
const TRACK_L = 250;
const TRACK_W = PANEL_W - TRACK_L - 30;

const ROWS = (() => {
  const r = rng(11);
  return ROW_NAMES.map((name, i) => {
    const left = r() * 0.25;
    const width = Math.min(0.92 - left, 0.3 + r() * 0.5);
    return {name, left, width, tone: i % 3, kfs: [0, 1, 2, 3].map(() => 0.04 + r() * 0.9)};
  });
})();

const toneBg = (t: number) =>
  t === 0 ? `${theme.colors.primary}55` : t === 1 ? `${theme.colors.accent}55` : "rgba(152,163,201,0.28)";
const toneBorder = (t: number) =>
  t === 0 ? theme.colors.primary : t === 1 ? theme.colors.accent : "rgba(152,163,201,0.5)";

export const OldWay: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = makeAt("old");
  const dur = sceneDuration("old");

  const zoom = 1 + p(frame, 0, dur, theme.ease.inOut) * 0.06;
  const play = p(frame, at(0.9), at(5.9), theme.ease.inOut);
  const panelIn = sp(frame, 4, fps, theme.spring.smooth);
  const sway = Math.sin(frame / 45) * 2;
  const firstDim = 1 - 0.55 * p(frame, at(1.0), at(1.4));
  const panelH = 100 + ROWS.length * ROW_H + 24;

  return (
    <div style={{position: "absolute", inset: 0}}>
      {/* "একটা সময় ছিল," */}
      <div style={{position: "absolute", top: 230, left: 0, right: 0, display: "flex", justifyContent: "center", opacity: firstDim}}>
        <Words text="একটা সময় ছিল," start={0} per={4} size={84} color={theme.colors.textDim} weight={theme.weights.semi} />
      </div>
      {/* Motion Graphics ভিডিও */}
      <div style={{position: "absolute", top: 350, left: 0, right: 0, display: "flex", justifyContent: "center"}}>
        <Words text="Motion Graphics ভিডিও" start={at(1.05)} per={5} size={92} hi={[0, 1]} />
      </div>

      {/* Complex editing workspace */}
      <div
        style={{
          position: "absolute",
          left: (1080 - PANEL_W) / 2,
          top: 600,
          width: PANEL_W,
          height: panelH,
          opacity: Math.min(1, Math.max(0, panelIn)),
          transform: `translateY(${(1 - panelIn) * 80}px) perspective(1800px) rotateX(9deg) rotateY(${-6 + sway}deg) scale(${zoom})`,
          borderRadius: theme.radius.md,
          background: "rgba(12,16,40,0.78)",
          border: `2px solid ${theme.colors.line}`,
          boxShadow: theme.shadow.card,
          overflow: "hidden",
        }}
      >
        {[0, 1, 2].map((d) => (
          <div
            key={d}
            style={{position: "absolute", left: 24 + d * 26, top: 20, width: 14, height: 14, borderRadius: "50%", background: "rgba(152,163,201,0.45)"}}
          />
        ))}
        {/* ruler */}
        {Array.from({length: 35}).map((_, i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              left: TRACK_L + (i * TRACK_W) / 34,
              top: 74,
              width: 2,
              height: i % 5 === 0 ? 18 : 9,
              background: "rgba(152,163,201,0.4)",
            }}
          />
        ))}
        {/* layer rows */}
        {ROWS.map((r, i) => {
          const start = at(0.2) + i * 3;
          const rowK = Math.min(1, Math.max(0, sp(frame, start, fps, theme.spring.snappy)));
          const barK = Math.max(0, sp(frame, start + 2, fps, theme.spring.snappy));
          return (
            <div key={r.name} style={{position: "absolute", left: 0, right: 0, top: 100 + i * ROW_H, height: ROW_H}}>
              <div
                style={{
                  position: "absolute",
                  left: 24,
                  top: 0,
                  height: ROW_H,
                  display: "flex",
                  alignItems: "center",
                  fontFamily: theme.fonts.display,
                  fontSize: 26,
                  color: theme.colors.textDim,
                  opacity: rowK,
                }}
              >
                {r.name}
              </div>
              <div
                style={{
                  position: "absolute",
                  left: TRACK_L + r.left * TRACK_W,
                  top: 14,
                  height: 36,
                  width: r.width * TRACK_W,
                  borderRadius: 10,
                  background: toneBg(r.tone),
                  border: `2px solid ${toneBorder(r.tone)}`,
                  transformOrigin: "left center",
                  transform: `scaleX(${Math.min(1.04, barK)})`,
                }}
              />
              {r.kfs.map((kf, j) => {
                const kk = Math.max(0, sp(frame, start + 14 + j * 3, fps, theme.spring.bouncy));
                return (
                  <div
                    key={j}
                    style={{
                      position: "absolute",
                      left: TRACK_L + kf * TRACK_W - 11,
                      top: 21,
                      width: 22,
                      height: 22,
                      borderRadius: 4,
                      background: theme.colors.text,
                      opacity: 0.8,
                      transform: `rotate(45deg) scale(${kk})`,
                    }}
                  />
                );
              })}
            </div>
          );
        })}
        {/* playhead */}
        <div
          style={{
            position: "absolute",
            left: TRACK_L + play * TRACK_W - 1.5,
            top: 60,
            width: 3,
            height: panelH - 80,
            background: theme.colors.primary,
            boxShadow: `0 0 18px ${theme.colors.primary}`,
          }}
        />
      </div>

      {/* hard-skill keywords */}
      <div
        style={{
          position: "absolute",
          top: 1440,
          left: 60,
          right: 60,
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          gap: 22,
        }}
      >
        <Chip label="After Effects" delay={at(3.28)} />
        <Chip label="Animation" delay={at(3.95)} />
        <Entrance delay={at(5.15)} y={26} cfg={theme.spring.snappy}>
          <Chip label="কঠিন Editing Skill" delay={0} active />
        </Entrance>
      </div>
    </div>
  );
};
