import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {p} from "../lib";
import {PRE} from "../timing";

type Props = {
  duration: number;
  first?: boolean;
  last?: boolean;
  children?: React.ReactNode;
};

/** Scale-through cross-dissolve wrapper used by every scene. */
export const SceneShell: React.FC<Props> = ({duration, first = false, last = false, children}) => {
  const frame = useCurrentFrame();
  const enter = first ? 1 : p(frame, 0, PRE + 4, theme.ease.out);
  const exitLen = last ? 16 : PRE;
  const exit = p(frame, duration - exitLen, duration - 1, theme.ease.in);
  const blur = (1 - enter) * 6 + exit * 8;
  return (
    <AbsoluteFill
      style={{
        opacity: enter * (1 - exit),
        transform: `scale(${(1.05 - 0.05 * enter) * (1 - 0.06 * exit)})`,
        filter: blur > 0.05 ? `blur(${blur}px)` : "none",
      }}
    >
      {children}
    </AbsoluteFill>
  );
};
