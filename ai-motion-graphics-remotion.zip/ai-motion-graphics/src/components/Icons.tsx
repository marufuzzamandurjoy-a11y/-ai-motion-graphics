import React from "react";
import {theme} from "../theme";

type IconProps = {size?: number; color?: string; stroke?: number};

const base = (size: number, color: string, stroke: number) => ({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: color,
  strokeWidth: stroke,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
});

export const SendIcon: React.FC<IconProps> = ({size = 48, color = theme.colors.text, stroke = 2.6}) => (
  <svg {...base(size, color, stroke)}>
    <path d="M12 19V5" />
    <path d="M5 12l7-7 7 7" />
  </svg>
);

export const CrossIcon: React.FC<IconProps> = ({size = 48, color = theme.colors.text, stroke = 2.6}) => (
  <svg {...base(size, color, stroke)}>
    <path d="M6 6l12 12" />
    <path d="M18 6L6 18" />
  </svg>
);

export const PenIcon: React.FC<IconProps> = ({size = 48, color = theme.colors.text, stroke = 2.2}) => (
  <svg {...base(size, color, stroke)}>
    <path d="M4 20l4-1 11-11-3-3L5 16z" />
    <path d="M14 7l3 3" />
  </svg>
);

export const ArrowIcon: React.FC<IconProps> = ({size = 48, color = theme.colors.text, stroke = 2.6}) => (
  <svg {...base(size, color, stroke)}>
    <path d="M4 12h16" />
    <path d="M14 6l6 6-6 6" />
  </svg>
);

export const SparkIcon: React.FC<IconProps> = ({size = 48, color = theme.colors.text}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <path d="M12 1.5l2.2 8.3 8.3 2.2-8.3 2.2L12 22.5l-2.2-8.3L1.5 12l8.3-2.2z" />
  </svg>
);
