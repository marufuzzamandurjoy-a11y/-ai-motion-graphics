import React from "react";
import {theme} from "../theme";
import {Entrance} from "./Entrance";

type Props = {
  label: string;
  delay: number;
  active?: boolean;
  size?: number;
  icon?: React.ReactNode;
  dim?: number;
};

/** Glass pill. `active` = the one hero-coloured element of the moment. */
export const Chip: React.FC<Props> = ({label, delay, active = false, size = 44, icon, dim = 1}) => (
  <Entrance delay={delay} y={26} cfg={theme.spring.snappy}>
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 14,
        padding: `${Math.round(size * 0.22)}px ${Math.round(size * 0.6)}px`,
        borderRadius: theme.radius.pill,
        background: active ? "rgba(47,123,255,0.20)" : theme.colors.glass,
        border: `2px solid ${active ? theme.colors.primary : theme.colors.line}`,
        boxShadow: active ? theme.shadow.glowPrimary : "none",
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: theme.weights.semi,
        lineHeight: 1.4,
        letterSpacing: 0,
        color: active ? theme.colors.text : theme.colors.textDim,
        opacity: dim,
      }}
    >
      {icon}
      {label}
    </div>
  </Entrance>
);
