import React from "react";
import {useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import type {SpringCfg} from "../theme";
import {sp} from "../lib";

type Props = {
  delay?: number;
  y?: number;
  s0?: number;
  cfg?: SpringCfg;
  style?: React.CSSProperties;
  children?: React.ReactNode;
};

/** Premium entrance: opacity + rise + scale, spring driven. */
export const Entrance: React.FC<Props> = ({
  delay = 0,
  y = 40,
  s0 = 0.94,
  cfg = theme.spring.smooth,
  style,
  children,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const k = sp(frame, delay, fps, cfg);
  const o = Math.min(1, Math.max(0, k));
  return (
    <div
      style={{
        opacity: o,
        transform: `translateY(${(1 - k) * y}px) scale(${s0 + (1 - s0) * k})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};
