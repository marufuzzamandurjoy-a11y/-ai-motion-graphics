import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {HEIGHT, WIDTH} from "../config";
import {mod, rng} from "../lib";

/** Layer 1 — animated gradient mesh (never a flat background). */
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 70) * 70;
  const d2 = Math.cos(frame / 90) * 60;
  const d3 = Math.sin(frame / 110) * 50;
  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(120% 80% at 50% 0%, ${theme.colors.bgAlt} 0%, ${theme.colors.bg} 62%)`,
      }}
    >
      <div
        style={{
          position: "absolute",
          width: 1300,
          height: 1300,
          borderRadius: "50%",
          top: -520,
          left: -420 + d1,
          filter: "blur(60px)",
          background: `radial-gradient(circle, ${theme.colors.primary}38, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 1100,
          height: 1100,
          borderRadius: "50%",
          bottom: -460,
          right: -380 - d2,
          filter: "blur(70px)",
          background: `radial-gradient(circle, ${theme.colors.accent}33, transparent 64%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 800,
          height: 800,
          borderRadius: "50%",
          top: 760 + d3,
          left: -300,
          filter: "blur(80px)",
          background: `radial-gradient(circle, ${theme.colors.primary}1F, transparent 66%)`,
        }}
      />
    </AbsoluteFill>
  );
};

/** Faint tech grid that slowly scrolls. */
export const Grid: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        opacity: 0.9,
        backgroundImage:
          "linear-gradient(rgba(255,255,255,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.035) 1px, transparent 1px)",
        backgroundSize: "90px 90px",
        backgroundPosition: `0px ${(frame * 0.4) % 90}px`,
        WebkitMaskImage: "radial-gradient(ellipse at center, black 18%, transparent 74%)",
        maskImage: "radial-gradient(ellipse at center, black 18%, transparent 74%)",
      }}
    />
  );
};

const PARTS = (() => {
  const r = rng(7);
  return Array.from({length: 64}).map(() => ({
    x: r() * WIDTH,
    y: r() * HEIGHT,
    s: 2 + r() * 4,
    v: 0.25 + r() * 0.8,
    ph: r() * 6.28,
    c: Math.floor(r() * 3),
  }));
})();

/** Deterministic floating dust (code-generated, no assets). */
export const Particles: React.FC = () => {
  const frame = useCurrentFrame();
  const cols = [theme.colors.text, theme.colors.primary, theme.colors.accent];
  return (
    <AbsoluteFill style={{pointerEvents: "none"}}>
      {PARTS.map((q, i) => {
        const y = mod(q.y - frame * q.v, HEIGHT + 40) - 20;
        const o = 0.2 + 0.45 * (0.5 + 0.5 * Math.sin(frame / 18 + q.ph));
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: q.x + Math.sin(frame / 50 + q.ph) * 14,
              top: y,
              width: q.s,
              height: q.s,
              borderRadius: "50%",
              background: cols[q.c],
              opacity: o,
              boxShadow: q.s > 4 ? `0 0 ${Math.round(q.s * 3)}px ${cols[q.c]}` : "none",
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

/** Colour grade — sits above content. */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: "none"}}>
    <AbsoluteFill
      style={{backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.18}}
    />
    <AbsoluteFill
      style={{
        background:
          "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 26%, transparent 72%, rgba(0,0,0,0.22))",
      }}
    />
  </AbsoluteFill>
);

/** Procedural film grain, no asset file. */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.07,
        mixBlendMode: "overlay",
      }}
    />
  );
};

/** Topmost layer. */
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: "radial-gradient(ellipse at center, transparent 52%, rgba(0,0,0,0.5) 100%)",
    }}
  />
);
