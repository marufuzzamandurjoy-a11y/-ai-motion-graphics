import React from "react";
import {useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {sp} from "../lib";

export const gradientText = (angle = 100): React.CSSProperties => ({
  background: `linear-gradient(${angle}deg, ${theme.colors.primary}, ${theme.colors.accent})`,
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  color: "transparent",
  WebkitTextFillColor: "transparent",
});

type WordsProps = {
  text: string;
  start: number; // local frame of the first word
  per?: number; // stagger frames between words
  size: number;
  weight?: number;
  color?: string;
  hi?: number[]; // indices of words drawn with the gradient
  align?: "center" | "left";
  maxWidth?: number;
  out?: number; // 0..1 exit progress
  glow?: boolean;
  style?: React.CSSProperties;
};

/**
 * Word-by-word reveal. Splits ONLY on whitespace — Bengali conjuncts, kar,
 * phola, ref and hasanta are never separated. letterSpacing is always 0.
 */
export const Words: React.FC<WordsProps> = ({
  text,
  start,
  per = 4,
  size,
  weight = theme.weights.bold,
  color = theme.colors.text,
  hi = [],
  align = "center",
  maxWidth = 960,
  out = 0,
  glow = false,
  style,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const words = text.split(/\s+/).filter(Boolean);
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align === "center" ? "center" : "flex-start",
        columnGap: Math.round(size * 0.26),
        rowGap: Math.round(size * 0.02),
        maxWidth,
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.42,
        letterSpacing: 0,
        color,
        ...style,
      }}
    >
      {words.map((w, i) => {
        const k = sp(frame, start + i * per, fps, theme.spring.snappy);
        const o = Math.min(1, Math.max(0, k));
        const isHi = hi.includes(i);
        const g = glow || isHi ? ` drop-shadow(0 0 ${Math.round(size * 0.18)}px rgba(47,123,255,0.55))` : "";
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              padding: "0 0.05em",
              opacity: o * (1 - out),
              transform: `translateY(${(1 - k) * 34 - out * 24}px) scale(${0.92 + 0.08 * Math.min(k, 1.04)})`,
              filter: `blur(${(1 - o) * 10 + out * 6}px)${g}`,
              ...(isHi ? gradientText() : {}),
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};
