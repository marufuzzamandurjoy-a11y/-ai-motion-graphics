import React from "react";
import {Audio, Sequence, interpolate, staticFile} from "remotion";
import {FPS, TOTAL_FRAMES} from "../config";
import {SFX, fr} from "../timing";

/** Short, low-volume, original synthesized SFX placed 2 frames BEFORE the visual lands. */
export const SfxTrack: React.FC = () => (
  <>
    {SFX.map((e, i) => (
      <Sequence key={i} from={Math.max(0, fr(e.t) - 2)} durationInFrames={Math.round(FPS * 1.2)}>
        <Audio src={staticFile(`sfx/${e.name}.wav`)} volume={e.v} />
      </Sequence>
    ))}
  </>
);

/** Very quiet original ambient pad (synthesized), faded in/out. */
export const MusicBed: React.FC = () => (
  <Audio
    src={staticFile("music/pad.wav")}
    volume={(f) =>
      interpolate(f, [0, 45, TOTAL_FRAMES - 45, TOTAL_FRAMES], [0, 0.12, 0.12, 0], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
      })
    }
  />
);
