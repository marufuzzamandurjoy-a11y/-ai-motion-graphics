import React from "react";
import {AbsoluteFill, Audio, Sequence, staticFile} from "remotion";
import type {MainProps} from "./config";
import {theme} from "./theme";
import {SCENES, sceneDuration, sceneFrom} from "./timing";
import type {SceneId} from "./timing";
import {BgMesh, Grade, Grain, Grid, Particles, Vignette} from "./components/Layers";
import {SceneShell} from "./components/Shell";
import {MusicBed, SfxTrack} from "./components/AudioLayer";
import {OldWay} from "./scenes/OldWay";
import {NowScene} from "./scenes/NowScene";
import {AIScene} from "./scenes/AIScene";
import {PromptScene} from "./scenes/PromptScene";
import {MagicScene} from "./scenes/MagicScene";
import {FreeScene} from "./scenes/FreeScene";
import {CtaScene} from "./scenes/CtaScene";

const SCENE_COMPONENTS: Record<SceneId, React.FC> = {
  old: OldWay,
  now: NowScene,
  ai: AIScene,
  prompt: PromptScene,
  magic: MagicScene,
  free: FreeScene,
  cta: CtaScene,
};

export const Main: React.FC<MainProps> = ({voiceover, sfx, music}) => (
  <AbsoluteFill style={{backgroundColor: theme.colors.bg}}>
    {/* layer 1–2: background mesh, grid, particles */}
    <BgMesh />
    <Grid />
    <Particles />

    {/* layer 3: scenes */}
    {SCENES.map((s, i) => {
      const Scene = SCENE_COMPONENTS[s.id];
      const dur = sceneDuration(s.id);
      return (
        <Sequence key={s.id} from={sceneFrom(s.id)} durationInFrames={dur}>
          <SceneShell duration={dur} first={i === 0} last={i === SCENES.length - 1}>
            <Scene />
          </SceneShell>
        </Sequence>
      );
    })}

    {/* layer 4–5: grade, grain, vignette */}
    <Grade />
    <Grain />
    <Vignette />

    {/* audio */}
    {voiceover ? <Audio src={staticFile("voiceover.mp3")} volume={1} /> : null}
    {music ? <MusicBed /> : null}
    {sfx ? <SfxTrack /> : null}
  </AbsoluteFill>
);
