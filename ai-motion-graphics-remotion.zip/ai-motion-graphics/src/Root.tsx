import React from "react";
import {Composition} from "remotion";
import {AUDIO_DEFAULTS, FPS, HEIGHT, TOTAL_FRAMES, WIDTH} from "./config";
import {Main} from "./Main";

export const Root: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
    defaultProps={AUDIO_DEFAULTS}
  />
);
