// Timing derived from the voiceover (pauses detected in the MP3 / SRT cues).
// All values are SECONDS; converted to frames with fr().
import {FPS, TOTAL_FRAMES} from "./config";

export const fr = (s: number) => Math.round(s * FPS);

/** Frames each scene starts early so it can cross-dissolve with the previous one. */
export const PRE = 8;

export type SceneId = "old" | "now" | "ai" | "prompt" | "magic" | "free" | "cta";

export const SCENES: {id: SceneId; start: number; end: number}[] = [
  {id: "old", start: 0, end: 6.15},
  {id: "now", start: 6.15, end: 12.7},
  {id: "ai", start: 12.7, end: 20.6},
  {id: "prompt", start: 20.6, end: 24.3},
  {id: "magic", start: 24.3, end: 29.4},
  {id: "free", start: 29.4, end: 35.3},
  {id: "cta", start: 35.3, end: 40.78},
];

const idx = (id: SceneId) => SCENES.findIndex((s) => s.id === id);

export const sceneFrom = (id: SceneId) => {
  const i = idx(id);
  return fr(SCENES[i].start) - (i === 0 ? 0 : PRE);
};

export const sceneDuration = (id: SceneId) => {
  const i = idx(id);
  const from = sceneFrom(id);
  const end = i === SCENES.length - 1 ? TOTAL_FRAMES : fr(SCENES[i].end);
  return end - from;
};

/** Returns a function converting global seconds → this scene's local frame. */
export const makeAt = (id: SceneId) => {
  const from = sceneFrom(id);
  return (sec: number) => fr(sec) - from;
};

// Subtle, short, original synthesized SFX (public/sfx/*.wav).
export type SfxName = "pop" | "click" | "tick" | "whoosh" | "chime" | "impact";
export const SFX: {t: number; name: SfxName; v: number}[] = [
  // Scene 1 — old way
  {t: 0.0, name: "whoosh", v: 0.22},
  {t: 3.28, name: "click", v: 0.26},
  {t: 3.95, name: "click", v: 0.24},
  {t: 5.2, name: "click", v: 0.27},
  // Scene 2 — "কিন্তু এখন?"
  {t: 6.0, name: "whoosh", v: 0.3},
  {t: 6.42, name: "impact", v: 0.3},
  {t: 9.95, name: "pop", v: 0.24},
  {t: 11.28, name: "click", v: 0.3},
  {t: 11.35, name: "pop", v: 0.26},
  // Scene 3 — AI
  {t: 12.5, name: "whoosh", v: 0.3},
  {t: 12.76, name: "impact", v: 0.3},
  {t: 12.95, name: "chime", v: 0.28},
  {t: 14.0, name: "pop", v: 0.26},
  {t: 14.25, name: "pop", v: 0.24},
  {t: 14.5, name: "pop", v: 0.22},
  {t: 14.75, name: "pop", v: 0.24},
  {t: 16.45, name: "pop", v: 0.26},
  {t: 17.3, name: "pop", v: 0.26},
  {t: 19.02, name: "chime", v: 0.3},
  // Scene 4 — prompt
  {t: 20.3, name: "whoosh", v: 0.26},
  {t: 20.82, name: "pop", v: 0.22},
  {t: 21.15, name: "pop", v: 0.24},
  {t: 23.5, name: "click", v: 0.32},
  // Scene 5 — magic
  {t: 24.2, name: "whoosh", v: 0.26},
  {t: 26.1, name: "whoosh", v: 0.28},
  {t: 26.9, name: "pop", v: 0.24},
  {t: 27.5, name: "pop", v: 0.24},
  {t: 28.4, name: "chime", v: 0.28},
  // Scene 6 — free
  {t: 29.2, name: "whoosh", v: 0.26},
  {t: 29.55, name: "pop", v: 0.22},
  {t: 32.1, name: "impact", v: 0.26},
  {t: 33.5, name: "click", v: 0.3},
  {t: 34.7, name: "click", v: 0.3},
  // Scene 7 — CTA
  {t: 35.15, name: "whoosh", v: 0.26},
  {t: 35.55, name: "pop", v: 0.22},
  {t: 36.85, name: "whoosh", v: 0.3},
  {t: 37.0, name: "chime", v: 0.26},
  {t: 38.5, name: "click", v: 0.3},
  {t: 39.1, name: "impact", v: 0.32},
  {t: 39.2, name: "chime", v: 0.3},
];
