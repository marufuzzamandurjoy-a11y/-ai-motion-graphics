# AI Motion Graphics (বাংলা) — Remotion project
9:16 · 1080×1920 · 30 FPS · Composition ID: `Main`

    npm install
    npx remotion studio src/index.ts
    npx remotion render src/index.ts Main out/video.mp4 --codec h264 --crf 17

- Studio-র Props panel থেকে `voiceover` / `sfx` / `music` on-off করা যায় (src/config.ts-এও আছে)।
- Timing: src/timing.ts (scene + SFX), public/voiceover.srt (voiceover-এর pause থেকে আনুমানিক cue)।
- Audio আবার তৈরি করতে: `npm run audio` (সব SFX/pad original, code দিয়ে synthesized)।
- Font (Hind Siliguri) প্রথমবার Google Fonts থেকে লোড হয়, তাই preview/render-এর সময় ইন্টারনেট লাগবে।
